# Buddies SPA

A dog digital identity, safety network, and future dog-to-dog buddy social graph.

## Product Positioning

Version 2 is designed as a production-oriented scaffold for:

- Dog QR identity profiles
- Lost dog safety mode
- Emergency/medical contact sharing
- Realtime alerts through Ably
- Cloudflare R2 photo storage
- PostgreSQL/Prisma data persistence
- Redis caching, counters, and cooldowns
- Mapbox last-seen mapping
- Future buddy graph, packs, events, and walking marketplace

## Tech Stack

| Layer | Tool |
|---|---|
| App | Next.js App Router |
| Frontend | React + TypeScript |
| Styling | Tailwind CSS |
| Database | PostgreSQL |
| ORM | Prisma |
| Storage | Cloudflare R2 |
| Cache | Upstash Redis |
| Realtime | Ably |
| Maps | Mapbox |
| Auth-ready | NextAuth placeholder |
| Testing | Vitest |
| CI | GitHub Actions |

## Setup

```bash
npm install
cp .env.example .env
npx prisma generate
npx prisma migrate dev --name init
npm run dev
```

## Push to GitHub

```bash
git clone https://github.com/Alendor22/Buddies_SPA.git
cd Buddies_SPA

# Copy/extract this project into the repo root, then:
git add .
git commit -m "feat: add Buddies SPA V2 scaffold"
git push origin master
```

## Environment Variables

See `.env.example`.

## V2 Domain Modules

```txt
src/modules/
├── dogs
├── owners
├── safety
├── qr
├── realtime
├── storage
├── maps
├── behavioral
└── social-graph
```

The `social-graph` module is intentionally scaffolded but not active in V2. The recommended product sequence is:

1. Dog identity
2. QR safety profile
3. Lost dog alerts
4. Scan analytics
5. Buddy graph
6. Packs/events
7. Walker marketplace

## Safety Note

Do not expose private owner address data on public dog pages. Only expose intentionally shareable emergency fields.
