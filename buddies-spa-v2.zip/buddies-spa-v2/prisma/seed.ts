import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  const owner = await prisma.owner.upsert({
    where: { email: "demo@buddies.local" },
    update: {},
    create: {
      email: "demo@buddies.local",
      name: "Demo Owner",
      cityId: "hoboken",
      behavioralProfile: {
        create: {
          stage: "IDENTIFIED"
        }
      }
    }
  });

  await prisma.dog.upsert({
    where: { slug: "luna-demo" },
    update: {},
    create: {
      ownerId: owner.id,
      name: "Luna",
      slug: "luna-demo",
      breed: "Husky",
      age: 3,
      size: "Medium",
      temperament: "Friendly",
      cityId: "hoboken",
      publicUrl: "http://localhost:3000/d/luna-demo"
    }
  });
}

main()
  .then(async () => prisma.$disconnect())
  .catch(async (error) => {
    console.error(error);
    await prisma.$disconnect();
    process.exit(1);
  });
