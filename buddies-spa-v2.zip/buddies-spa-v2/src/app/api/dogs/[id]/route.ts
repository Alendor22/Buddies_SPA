import { NextResponse } from "next/server";
import { dogService } from "@/modules/dogs/dog.service";

export async function GET(
  _req: Request,
  { params }: { params: { id: string } }
) {
  const dog = await dogService.getDogById(params.id);

  if (!dog) {
    return NextResponse.json({ error: "Dog not found" }, { status: 404 });
  }

  return NextResponse.json(dog);
}
