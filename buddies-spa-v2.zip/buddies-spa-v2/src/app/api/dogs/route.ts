import { NextResponse } from "next/server";
import { dogService } from "@/modules/dogs/dog.service";
import { createDogSchema } from "@/modules/dogs/dog.schemas";

export async function POST(req: Request) {
  const parsed = createDogSchema.safeParse(await req.json());

  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid dog payload", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const dog = await dogService.createDog(parsed.data);

  return NextResponse.json(dog, { status: 201 });
}
