import { NextResponse } from "next/server";
import { safetyService } from "@/modules/safety/safety.service";
import { lostDogSchema } from "@/modules/safety/safety.schemas";

export async function POST(req: Request) {
  const parsed = lostDogSchema.safeParse(await req.json());

  if (!parsed.success) {
    return NextResponse.json(
      { error: "Invalid lost dog payload", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const dog = await safetyService.activateLostDogMode(parsed.data);

  return NextResponse.json({
    message: "Lost dog mode activated",
    dog
  });
}
