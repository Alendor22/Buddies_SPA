import { NextResponse } from "next/server";
import { qrService } from "@/modules/qr/qr.service";
import { qrScanSchema } from "@/modules/qr/qr.schemas";

export async function POST(req: Request) {
  const parsed = qrScanSchema.safeParse(await req.json());

  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid QR scan payload" }, { status: 400 });
  }

  const result = await qrService.recordScan(parsed.data.dogId);

  return NextResponse.json(result);
}
