import { NextResponse } from "next/server";
import { storageService } from "@/modules/storage/storage.service";

export async function POST(req: Request) {
  const formData = await req.formData();
  const file = formData.get("file");

  if (!(file instanceof File)) {
    return NextResponse.json({ error: "No file uploaded" }, { status: 400 });
  }

  const url = await storageService.uploadDogPhoto(file);

  return NextResponse.json({ url });
}
