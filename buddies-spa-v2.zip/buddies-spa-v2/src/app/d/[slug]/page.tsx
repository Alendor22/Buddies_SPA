import { notFound } from "next/navigation";
import { dogService } from "@/modules/dogs/dog.service";
import LostDogBanner from "@/components/safety/LostDogBanner";
import MapBoxView from "@/components/maps/MapBoxView";
import QRScanTracker from "@/components/qr/QRScanTracker";

export default async function PublicDogPage({
  params
}: {
  params: { slug: string };
}) {
  const dog = await dogService.getPublicDogBySlug(params.slug);

  if (!dog) notFound();

  return (
    <main className="min-h-screen bg-slate-50 p-6">
      <QRScanTracker dogId={dog.id} />

      <section className="mx-auto max-w-xl rounded-2xl bg-white p-6 shadow">
        {dog.status === "LOST" && <LostDogBanner />}

        {dog.photoUrl && (
          <img
            src={dog.photoUrl}
            alt={dog.name}
            className="mb-4 h-72 w-full rounded-xl object-cover"
          />
        )}

        <h1 className="text-3xl font-bold">{dog.name}</h1>
        <p className="mt-2 text-slate-600">
          {dog.breed || "Breed not listed"} {dog.age ? `• ${dog.age} years old` : ""}
        </p>

        <div className="mt-6 space-y-3">
          <p><strong>Temperament:</strong> {dog.temperament || "Not listed"}</p>
          <p><strong>Medical Notes:</strong> {dog.medicalNotes || "None listed"}</p>
          <p><strong>Allergies:</strong> {dog.allergies || "None listed"}</p>
          <p><strong>Medications:</strong> {dog.medications || "None listed"}</p>

          <p>
            <strong>Emergency Contact:</strong>{" "}
            {dog.emergencyContactName || "Not listed"}{" "}
            {dog.emergencyContactPhone && (
              <a className="text-blue-600 underline" href={`tel:${dog.emergencyContactPhone}`}>
                {dog.emergencyContactPhone}
              </a>
            )}
          </p>

          <p>
            <strong>Vet:</strong> {dog.vetName || "Not listed"}{" "}
            {dog.vetPhone && (
              <a className="text-blue-600 underline" href={`tel:${dog.vetPhone}`}>
                {dog.vetPhone}
              </a>
            )}
          </p>
        </div>

        {dog.status === "LOST" && dog.lastSeenLat && dog.lastSeenLng && (
          <div className="mt-6">
            <h2 className="mb-2 text-xl font-semibold">Last Seen</h2>
            <MapBoxView lat={dog.lastSeenLat} lng={dog.lastSeenLng} />
          </div>
        )}
      </section>
    </main>
  );
}
