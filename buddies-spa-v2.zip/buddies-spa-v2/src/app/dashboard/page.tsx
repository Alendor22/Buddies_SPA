import RealtimeDogAlerts from "@/components/realtime/RealtimeDogAlerts";
import DogProfileForm from "@/components/dogs/DogProfileForm";

export default function DashboardPage() {
  const defaultCityId = process.env.NEXT_PUBLIC_DEFAULT_CITY_ID || "hoboken";

  return (
    <main className="min-h-screen bg-slate-50 p-6">
      <RealtimeDogAlerts cityId={defaultCityId} />

      <section className="mx-auto max-w-5xl">
        <h1 className="text-3xl font-bold">Dog Identity Dashboard</h1>

        <p className="mt-2 text-slate-600">
          Create dog profiles, manage QR identities, and activate lost dog mode.
        </p>

        <div className="mt-8 grid gap-6 md:grid-cols-2">
          <DogProfileForm ownerId="REPLACE_WITH_AUTH_OWNER_ID" />
          <div className="rounded-2xl bg-white p-6 shadow">
            <h2 className="text-xl font-semibold">V2 Status</h2>
            <p className="mt-3 text-slate-600">
              Authentication is intentionally left as a production integration step.
              Replace the placeholder owner ID with authenticated owner context.
            </p>
          </div>
        </div>
      </section>
    </main>
  );
}
