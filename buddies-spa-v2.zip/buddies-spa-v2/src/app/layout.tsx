import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Buddies SPA",
  description: "Dog digital identity and safety network"
};

export default function RootLayout({
  children
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
