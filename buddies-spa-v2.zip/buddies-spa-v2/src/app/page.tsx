import Link from "next/link";
import { ShieldCheck, QrCode, MapPin, Radio } from "lucide-react";

export default function HomePage() {
  return (
    <main className="min-h-screen p-6">
      <section className="mx-auto max-w-5xl rounded-3xl bg-white p-8 shadow">
        <div className="max-w-2xl">
          <p className="text-sm font-semibold uppercase tracking-wide text-slate-500">
            Dog identity + safety network
          </p>
          <h1 className="mt-3 text-5xl font-bold tracking-tight">
            Buddies SPA
          </h1>
          <p className="mt-5 text-lg text-slate-600">
            Create a QR-enabled digital identity for every dog, support lost dog
            recovery, and prepare the foundation for a dog-to-dog buddy graph.
          </p>

          <div className="mt-8 flex gap-3">
            <Link
              href="/dashboard"
              className="rounded-xl bg-slate-950 px-5 py-3 text-white"
            >
              Open dashboard
            </Link>
            <Link
              href="/d/luna-demo"
              className="rounded-xl border px-5 py-3"
            >
              View demo profile
            </Link>
          </div>
        </div>

        <div className="mt-10 grid gap-4 md:grid-cols-4">
          {[
            ["QR identity", QrCode],
            ["Lost dog mode", ShieldCheck],
            ["Last-seen maps", MapPin],
            ["Realtime alerts", Radio]
          ].map(([label, Icon]) => (
            <div key={String(label)} className="rounded-2xl border p-5">
              <Icon className="h-6 w-6" />
              <p className="mt-3 font-semibold">{String(label)}</p>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
