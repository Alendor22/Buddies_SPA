/**
 * Auth placeholder.
 *
 * Recommended next step:
 * - Add NextAuth provider configuration or Clerk.
 * - Replace dashboard ownerId placeholder with authenticated owner context.
 */
export async function getCurrentOwnerId() {
  return null;
}
