import type { DogDTO } from "@/modules/dogs/dog.types";
import QRBlock from "@/components/qr/QRBlock";

export default function DogCard({ dog }: { dog: DogDTO }) {
  return (
    <article className="rounded-2xl bg-white p-5 shadow">
      {dog.photoUrl && (
        <img
          src={dog.photoUrl}
          alt={dog.name}
          className="mb-4 h-48 w-full rounded-xl object-cover"
        />
      )}

      <h2 className="text-2xl font-bold">{dog.name}</h2>
      <p className="text-slate-600">{dog.breed || "Breed not listed"}</p>

      {dog.qrUrl && dog.publicUrl && (
        <div className="mt-5">
          <QRBlock qrUrl={dog.qrUrl} publicUrl={dog.publicUrl} />
        </div>
      )}
    </article>
  );
}
