"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";

export default function DogProfileForm({ ownerId }: { ownerId: string }) {
  const [name, setName] = useState("");
  const [breed, setBreed] = useState("");

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const res = await fetch("/api/dogs", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        ownerId,
        name,
        breed,
        cityId: process.env.NEXT_PUBLIC_DEFAULT_CITY_ID || "hoboken"
      })
    });

    if (!res.ok) {
      alert("Failed to create dog profile. Confirm ownerId/auth setup.");
      return;
    }

    setName("");
    setBreed("");
    alert("Dog profile created.");
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4 rounded-2xl bg-white p-6 shadow">
      <h2 className="text-xl font-semibold">Create Dog Profile</h2>

      <div>
        <label className="block text-sm font-medium">Dog name</label>
        <input
          className="mt-1 w-full rounded-xl border p-3"
          value={name}
          onChange={(event) => setName(event.target.value)}
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium">Breed</label>
        <input
          className="mt-1 w-full rounded-xl border p-3"
          value={breed}
          onChange={(event) => setBreed(event.target.value)}
        />
      </div>

      <Button type="submit">Create Profile</Button>
    </form>
  );
}
