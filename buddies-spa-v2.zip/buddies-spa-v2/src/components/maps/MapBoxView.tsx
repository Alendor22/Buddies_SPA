"use client";

import Map, { Marker } from "react-map-gl";
import "mapbox-gl/dist/mapbox-gl.css";

type Props = {
  lat: number;
  lng: number;
};

export default function MapBoxView({ lat, lng }: Props) {
  return (
    <div className="h-72 overflow-hidden rounded-xl">
      <Map
        mapboxAccessToken={process.env.NEXT_PUBLIC_MAPBOX_TOKEN}
        initialViewState={{
          latitude: lat,
          longitude: lng,
          zoom: 14
        }}
        mapStyle="mapbox://styles/mapbox/streets-v12"
      >
        <Marker latitude={lat} longitude={lng} />
      </Map>
    </div>
  );
}
