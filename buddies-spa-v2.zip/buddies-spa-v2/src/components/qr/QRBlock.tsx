type Props = {
  qrUrl: string;
  publicUrl: string;
};

export default function QRBlock({ qrUrl, publicUrl }: Props) {
  return (
    <div className="rounded-xl border bg-white p-4 text-center shadow-sm">
      <img src={qrUrl} alt="Dog QR Code" className="mx-auto h-48 w-48" />

      <p className="mt-3 text-sm text-slate-600">
        Scan to view this dog&apos;s public safety profile.
      </p>

      <a href={publicUrl} className="mt-2 block text-sm text-blue-600 underline">
        Open public profile
      </a>
    </div>
  );
}
