"use client";

import { useEffect } from "react";

export default function QRScanTracker({ dogId }: { dogId: string }) {
  useEffect(() => {
    fetch("/api/qr-scan", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ dogId })
    }).catch(() => {
      // Non-critical analytics event.
    });
  }, [dogId]);

  return null;
}
