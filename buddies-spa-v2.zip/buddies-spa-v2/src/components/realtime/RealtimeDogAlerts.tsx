"use client";

import { useEffect, useState } from "react";
import Ably from "ably";

type Alert = {
  type: "LOST_DOG" | "DOG_FOUND" | "QR_SCAN";
  message: string;
  dogId?: string;
};

export default function RealtimeDogAlerts({ cityId }: { cityId: string }) {
  const [alerts, setAlerts] = useState<Alert[]>([]);

  useEffect(() => {
    const client = new Ably.Realtime({
      authUrl: "/api/ably-token"
    });

    const channel = client.channels.get(`city:${cityId}`);

    channel.subscribe("lost-dog-alert", (message) => {
      setAlerts((prev) => [message.data as Alert, ...prev]);
    });

    return () => {
      channel.unsubscribe();
      client.close();
    };
  }, [cityId]);

  return (
    <div className="fixed bottom-4 right-4 z-50 space-y-3">
      {alerts.slice(0, 3).map((alert, index) => (
        <div key={index} className="max-w-sm rounded-xl border bg-white p-4 shadow-lg">
          <p className="font-semibold">{alert.message}</p>
        </div>
      ))}
    </div>
  );
}
