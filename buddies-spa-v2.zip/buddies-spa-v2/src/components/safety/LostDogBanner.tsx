export default function LostDogBanner() {
  return (
    <div className="mb-4 rounded-xl border border-red-300 bg-red-50 p-4 text-red-800">
      <h2 className="text-xl font-bold">Lost Dog Alert</h2>
      <p className="mt-1">
        This dog has been marked as lost. If found, contact the emergency contact
        listed below.
      </p>
    </div>
  );
}
