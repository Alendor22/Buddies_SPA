import Ably from "ably";

export const ablyServer = new Ably.Rest(process.env.ABLY_API_KEY || "");

export type RealtimeEvent =
  | "lost-dog-alert"
  | "dog-found-alert"
  | "qr-scan-alert"
  | "emergency-contact-clicked"
  | "dog-status-updated";

export async function publishRealtimeEvent({
  channel,
  event,
  payload
}: {
  channel: string;
  event: RealtimeEvent;
  payload: Record<string, unknown>;
}) {
  const ablyChannel = ablyServer.channels.get(channel);
  await ablyChannel.publish(event, payload);
}
