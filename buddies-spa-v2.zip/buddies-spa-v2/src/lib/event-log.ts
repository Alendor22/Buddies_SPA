import { prisma } from "@/lib/prisma";

export async function logEvent(input: {
  actorId?: string;
  dogId?: string;
  cityId?: string;
  type: string;
  metadata?: Record<string, unknown>;
}) {
  return prisma.eventLog.create({
    data: {
      actorId: input.actorId,
      dogId: input.dogId,
      cityId: input.cityId,
      type: input.type,
      metadata: input.metadata
    }
  });
}
