import QRCode from "qrcode";

export async function generateDogQR(slug: string) {
  const appUrl = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";
  const url = `${appUrl}/d/${slug}`;

  const qrDataUrl = await QRCode.toDataURL(url, {
    margin: 2,
    width: 512
  });

  return {
    url,
    qrDataUrl
  };
}
