import { describe, expect, it } from "vitest";
import { calculateCommunityScore, resolveBehavioralStage } from "./behavioral.service";

describe("behavioral service", () => {
  it("calculates community score", () => {
    expect(
      calculateCommunityScore({
        buddyCount: 10,
        eventsHosted: 2,
        successfulReferrals: 3,
        lostDogAssists: 1
      })
    ).toBe(100);
  });

  it("resolves advocate stage", () => {
    expect(
      resolveBehavioralStage({
        hasDogProfile: true,
        buddyCount: 10,
        packCount: 2,
        eventsHosted: 1,
        referralCount: 5
      })
    ).toBe("ADVOCATE");
  });
});
