export function calculateCommunityScore(input: {
  buddyCount: number;
  eventsHosted: number;
  successfulReferrals: number;
  lostDogAssists: number;
}) {
  return (
    input.buddyCount * 1 +
    input.eventsHosted * 10 +
    input.successfulReferrals * 15 +
    input.lostDogAssists * 25
  );
}

export function resolveBehavioralStage(input: {
  hasDogProfile: boolean;
  buddyCount: number;
  packCount: number;
  eventsHosted: number;
  referralCount: number;
}) {
  if (input.referralCount >= 5) return "ADVOCATE";
  if (input.eventsHosted >= 1) return "LEADER";
  if (input.packCount >= 1) return "BELONGING";
  if (input.buddyCount >= 1) return "CONNECTED";
  if (input.hasDogProfile) return "IDENTIFIED";
  return "SAFE";
}
