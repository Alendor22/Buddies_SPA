import { z } from "zod";

export const createDogSchema = z.object({
  ownerId: z.string().uuid(),
  name: z.string().min(1),
  breed: z.string().optional(),
  age: z.number().int().positive().optional(),
  size: z.string().optional(),
  temperament: z.string().optional(),
  photoUrl: z.string().url().optional(),
  cityId: z.string().optional(),
  emergencyContactName: z.string().optional(),
  emergencyContactPhone: z.string().optional(),
  vetName: z.string().optional(),
  vetPhone: z.string().optional(),
  medicalNotes: z.string().optional(),
  allergies: z.string().optional(),
  medications: z.string().optional()
});

export type CreateDogInput = z.infer<typeof createDogSchema>;
