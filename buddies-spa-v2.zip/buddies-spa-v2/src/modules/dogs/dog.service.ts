import { prisma } from "@/lib/prisma";
import { generateDogQR } from "@/lib/qr";
import { logEvent } from "@/lib/event-log";
import type { CreateDogInput } from "./dog.schemas";

function slugify(name: string) {
  return `${name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")}-${crypto.randomUUID().slice(0, 8)}`;
}

export const dogService = {
  async createDog(input: CreateDogInput) {
    const slug = slugify(input.name);
    const { url, qrDataUrl } = await generateDogQR(slug);

    const dog = await prisma.dog.create({
      data: {
        ownerId: input.ownerId,
        name: input.name,
        slug,
        breed: input.breed,
        age: input.age,
        size: input.size,
        temperament: input.temperament,
        photoUrl: input.photoUrl,
        cityId: input.cityId,
        publicUrl: url,
        qrUrl: qrDataUrl,
        emergencyContactName: input.emergencyContactName,
        emergencyContactPhone: input.emergencyContactPhone,
        vetName: input.vetName,
        vetPhone: input.vetPhone,
        medicalNotes: input.medicalNotes,
        allergies: input.allergies,
        medications: input.medications
      }
    });

    await logEvent({
      actorId: input.ownerId,
      dogId: dog.id,
      cityId: dog.cityId || undefined,
      type: "DOG_PROFILE_CREATED"
    });

    return dog;
  },

  async getDogById(id: string) {
    return prisma.dog.findUnique({
      where: { id },
      include: {
        owner: true,
        reputation: true,
        achievements: true
      }
    });
  },

  async getPublicDogBySlug(slug: string) {
    return prisma.dog.findUnique({
      where: { slug }
    });
  }
};
