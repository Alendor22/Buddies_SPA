export type DogStatus = "SAFE" | "LOST";

export interface DogDTO {
  id: string;
  ownerId: string;
  name: string;
  slug: string;
  breed?: string | null;
  age?: number | null;
  size?: string | null;
  temperament?: string | null;
  photoUrl?: string | null;
  status: DogStatus;
  emergencyContactName?: string | null;
  emergencyContactPhone?: string | null;
  vetName?: string | null;
  vetPhone?: string | null;
  medicalNotes?: string | null;
  allergies?: string | null;
  medications?: string | null;
  lastSeenLat?: number | null;
  lastSeenLng?: number | null;
  lastSeenAt?: Date | null;
  cityId?: string | null;
  qrUrl?: string | null;
  publicUrl?: string | null;
}
