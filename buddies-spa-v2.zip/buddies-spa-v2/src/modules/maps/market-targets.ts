export const initialMarkets = [
  {
    id: "hoboken",
    name: "Hoboken",
    state: "NJ",
    center: { lat: 40.74399, lng: -74.03236 }
  },
  {
    id: "jersey-city",
    name: "Jersey City",
    state: "NJ",
    center: { lat: 40.71775, lng: -74.04314 }
  },
  {
    id: "brooklyn",
    name: "Brooklyn",
    state: "NY",
    center: { lat: 40.67818, lng: -73.94416 }
  }
];
