import { z } from "zod";

export const qrScanSchema = z.object({
  dogId: z.string().uuid()
});

export type QRScanInput = z.infer<typeof qrScanSchema>;
