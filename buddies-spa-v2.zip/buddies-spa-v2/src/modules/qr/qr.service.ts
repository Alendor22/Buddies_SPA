import { prisma } from "@/lib/prisma";
import { redis } from "@/lib/redis";
import { publishRealtimeEvent } from "@/lib/ably";
import { logEvent } from "@/lib/event-log";

export const qrService = {
  async recordScan(dogId: string) {
    const dog = await prisma.dog.findUnique({
      where: { id: dogId }
    });

    if (!dog) {
      return {
        ok: false,
        error: "Dog not found"
      };
    }

    const scanCount = await redis.incr(`qr-scans:${dogId}`);

    await logEvent({
      dogId,
      cityId: dog.cityId || undefined,
      type: "QR_SCANNED",
      metadata: { scanCount }
    });

    await publishRealtimeEvent({
      channel: `dog:${dogId}`,
      event: "qr-scan-alert",
      payload: {
        type: "QR_SCAN",
        dogId,
        scanCount,
        message: `${dog.name}'s QR profile was scanned.`
      }
    });

    return {
      ok: true,
      scanCount
    };
  }
};
