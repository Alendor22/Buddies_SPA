export const realtimeChannels = {
  city: (cityId: string) => `city:${cityId}`,
  dog: (dogId: string) => `dog:${dogId}`,
  owner: (ownerId: string) => `owner:${ownerId}`,
  park: (parkId: string) => `park:${parkId}`
};
