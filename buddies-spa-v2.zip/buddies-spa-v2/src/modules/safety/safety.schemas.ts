import { z } from "zod";

export const lostDogSchema = z.object({
  dogId: z.string().uuid(),
  lat: z.number(),
  lng: z.number(),
  cityId: z.string().min(1)
});

export type LostDogInput = z.infer<typeof lostDogSchema>;
