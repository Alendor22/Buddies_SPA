import { prisma } from "@/lib/prisma";
import { redis } from "@/lib/redis";
import { publishRealtimeEvent } from "@/lib/ably";
import { logEvent } from "@/lib/event-log";
import type { LostDogInput } from "./safety.schemas";

export const safetyService = {
  async activateLostDogMode(input: LostDogInput) {
    const dog = await prisma.dog.update({
      where: { id: input.dogId },
      data: {
        status: "LOST",
        lastSeenLat: input.lat,
        lastSeenLng: input.lng,
        lastSeenAt: new Date(),
        cityId: input.cityId
      }
    });

    await redis.set(`lost-dog:${dog.id}`, dog, {
      ex: 60 * 60 * 24 * 7
    });

    await logEvent({
      dogId: dog.id,
      cityId: input.cityId,
      type: "LOST_DOG_ACTIVATED",
      metadata: {
        lat: input.lat,
        lng: input.lng
      }
    });

    await publishRealtimeEvent({
      channel: `city:${input.cityId}`,
      event: "lost-dog-alert",
      payload: {
        type: "LOST_DOG",
        dogId: dog.id,
        name: dog.name,
        message: `${dog.name} has been reported lost nearby.`,
        lat: input.lat,
        lng: input.lng
      }
    });

    return dog;
  }
};
