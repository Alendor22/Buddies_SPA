import { prisma } from "@/lib/prisma";

export const socialGraphService = {
  async addBuddy(dogId: string, buddyId: string) {
    if (dogId === buddyId) {
      throw new Error("A dog cannot be its own buddy.");
    }

    await prisma.dogBuddy.createMany({
      data: [
        { dogId, buddyId },
        { dogId: buddyId, buddyId: dogId }
      ],
      skipDuplicates: true
    });

    return { dogId, buddyId };
  },

  async getBuddies(dogId: string) {
    const links = await prisma.dogBuddy.findMany({
      where: { dogId },
      include: { buddy: true },
      orderBy: { createdAt: "desc" }
    });

    return links.map((link) => link.buddy);
  }
};
