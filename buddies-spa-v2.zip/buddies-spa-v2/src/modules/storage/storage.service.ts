import { uploadToR2 } from "@/lib/r2";

export const storageService = {
  async uploadDogPhoto(file: File) {
    const buffer = Buffer.from(await file.arrayBuffer());
    const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "-");
    const key = `dog-photos/${crypto.randomUUID()}-${safeName}`;

    return uploadToR2({
      key,
      body: buffer,
      contentType: file.type
    });
  }
};
